let fV=t=>['blocked','plain','empty','village','farm','mine'].indexOf(t);let gId=()=>{let r=()=>Math.random().toString(36).substr(2,9);return r()+r()};let rsc=s=>s.replace(/[^a-zA-Z0-9_\- ]/g,'')
